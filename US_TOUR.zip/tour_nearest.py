"""
Name: Varnit Tewari
email:vxt6823@rit.edu
This implements the nearest neighbour  strategy. The starting place isthe first place in the file anf then it goes to the closest place.

"""


import tour_utils
import turtle

def get_list1(lst):
    """
    the main function to get the nearest neighbour an do the turtle functons for it
    :param lst: list of places
    :return:
    """
    order=""
    tot_dist=0
    a=lst[0].name

    while len(lst)>1:
        for i in range(0,len(lst)-1):
            min_dist=tour_utils.distance(lst[0].x,lst[1].x,lst[0].y,lst[1].y)
            for j in range(1,len(lst)):
                dist=tour_utils.distance(lst[0].x,lst[j].x,lst[0].y,lst[j].y)
                if dist<min_dist:
                    min_dist=dist
                    location=j
                elif dist==min_dist:
                    location=1
            order = order + lst[location].name + "=>"
            turtle.goto(lst[location].x,lst[location].y)
            coordinates=(lst[location].x,lst[location].y)
            turtle.write((lst[location].name,coordinates))

            s=lst[location]
            lst.remove(lst[location])
            tot_dist+=min_dist
            lst=lst[1:]
            lst.insert(0,s)
    print(a, "=>", order, a)
    print(" Distance :", tot_dist)
    print(" Close the canvas window to quit")



def init1():
    """
    for initialising the function and start the function
    :return:
    """
    tour_utils.init()
    lst = tour_utils.get_list()
    a = lst[0].name
    b = lst[0]
    turtle.goto(b.x, b.y)
    coordinates1 = (b.x, b.y)
    turtle.down()
    turtle.write((a, coordinates1))
    get_list1(lst)
    turtle.goto(b.x, b.y)
init1()

turtle.done()

