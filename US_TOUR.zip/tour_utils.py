"""
Name: Varnit Tewari
email:vxt6823@rit.edu
This contains all the commmon things in both the functions. Other files call it to get the values
"""


from rit_lib import *
import turtle
import math

class place(struct):
    _slots=((str, "name"),(float ,"x" ),( float,"y"))

def init():
    """
    Initialising the screen
    :return:
    """
    turtle.screensize(600, 600)
    turtle.setworldcoordinates(0, 0, 1000, 1000)
    turtle.up()

def get_list():
    """
    to get the list
    :return:
    """
    order=""
    print ("Welcome to the Dippy Hippy Tour. Get on the bus!")
    file = input (" Enter filename:")
    lst = []
    for line in open (file):
        shortlst = line.split(",")
        p=place(shortlst[0], float(shortlst[1]), float(shortlst[2]))
        lst.append(p)
    print(" Reading ", file, len(lst), "places")
    return lst



def distance(x1,x2,y1,y2):
    """
    to compute the distance between two points
    :param x1:
    :param x2:
    :param y1:
    :param y2:
    :return:
    """
    d= math.sqrt((x2-x1)**2 + (y2-y1)**2)
    return d

