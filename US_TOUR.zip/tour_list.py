"""
Name: Varnit Tewari
email:vxt6823@rit.edu
This implements the list order strategy. The starting place isthe first place in the file and then it goes to the next value.
"""



import tour_utils
import turtle


def get_list2():
    """
    the main function to get the list and start the functions by goig to the next member of the list and doing turtle functions
    :return:
    """
    order=""
    dist=0
    lst = tour_utils.get_list()
    tour_utils.init()
    a = lst[0].name
    b = lst[0]
    turtle.goto(b.x, b.y)
    coordinates1 = (b.x, b.y)
    turtle.down()
    turtle.write((a, coordinates1))
    for i in range(0,len(lst)):
       order= order + lst[i].name +"=>"
    print (order, lst[0].name)
    while len(lst)>1:
        min_dist=tour_utils.distance(lst[0].x,lst[1].x,lst[0].y,lst[1].y)
        turtle.goto(lst[1].x, lst[1].y)
        coordinates = (lst[1].x, lst[1].y)
        turtle.write((lst[1].name, coordinates))
        dist += min_dist
        lst=lst[1:]


    print ( " Distance :", dist)
    print (" Close the canvas window to quit")
    turtle.goto(b.x, b.y)

get_list2()
turtle.done()