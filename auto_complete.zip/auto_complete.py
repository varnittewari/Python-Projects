"""
Name: Varnit Tewari
Email: vxt6823@rit.edu
Function to find all the words starting with the entered prefix. First , linearly in an unsorted list, secondly, linearly in a sorted list and then does a  binary search.
Pre conditions: do not enter an empty string as prefix in the first go
"""


import sort
import bsearch


def auto_complete_main():
    """
    Function to
    - promt the user for a file name
    - reads the words of the given file to a list
    - sorts the list alphabetically
    - checks the string entered in pre and then calls the various functions
    :return:
    """
    file = input("Enter file name:")
    lst = []
    for line in open(file):
        lst += line.split()
    ulst = lst.copy()
    slst = sort.sorts(lst)
    print("The unsorted list :",ulst)
    print("The sorted list :", slst)
    print("Welcome to Auto-complete!")
    print("Usage: Enter a prefix to auto-complete.")
    print("Entering nothing will search for the word with that prefix.")
    print("Enter <QUIT> when asked for a prefix to exit.")
    t=True
    s=0
    while t==True:
        pre = input("Enter a prefix to search for:")
        if pre=="<QUIT>":
            print("Exiting Auto-complete! Good bye.")
            t=False

        elif pre=="":
            if m==[]:
                print("There are no matches")
                print()
            elif len(m) == 1:
                print("Match for unsorted list:", m[0])
                print(" Match for sorted list:", n[0])
                print("Match for binary search is ", o[0])
                print()
                m = lin_search(ulst, empty_condition)
                n = lin_search1(slst, empty_condition)
                begin = 0
                end = len(lst)
                o = bsearch.bin_search(lst, empty_condition, begin, end)
            else:
                print("Match for unsorted list:", m[0])
                m=m[1:]
                print(" Match for sorted list:", n[0])
                n=n[1:]
                print("Match for binary search is ", o[0])
                print()
                o=o[1:]

        else:
            empty_condition = pre
            m=lin_search(ulst,pre)
            if m!=[] and len(m) != 1:
                print("Match for unsorted list:", m[0])
                m = m[1:]
                n = lin_search1(slst, pre)
                print(" Match for sorted list:", n[0])
                n = n[1:]
                begin = 0
                end = len(lst)
                o = bsearch.bin_search(lst, pre, begin, end)
                print("Match for binary search is ", o[0])
                print()
                o = o[1:]
            elif m!=[]:
                print("Match for unsorted list:", m[0])
                n = lin_search1(slst, pre)
                print(" Match for sorted list:", n[0])
                begin = 0
                end = len(lst)
                o = bsearch.bin_search(lst, pre, begin, end)
                print("Match for binary search is ", o[0])
                print()
            elif m==[]:
                print("There are no matches")
                print()


def lin_search(x,pre):
    """
    A function to linearly search for the word in the unsorted list
    :param x:
    :param pre:
    :return:
    """
    lst1=[]
    for idx in range(0,len(x)):
        a= x[idx]
        if a[0:len(pre)]==pre:
            lst1 += [a]
    return lst1


def lin_search1(lst,pre):
    """
    a function to linearly search for the word in a sorted list
    :param lst:
    :param pre:
    :return:
    """
    lst2=[]
    for indx in range(0,len(lst)):
        a= lst[indx]
        if a[0:len(pre)]==pre:
           lst2 += [a]
    return lst2



auto_complete_main()


