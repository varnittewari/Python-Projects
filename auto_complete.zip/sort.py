"""
Name: Varnit Tewari
Email: vxt6823@rit.edu
Function to sort the words alphabetically
"""


def main():
    """
    Function to
    - promt the user for a file name
    - reads the words of the given file to a list
    - arranges the list alphabetically
    :return:
    """
    file = input(" Enter file ne:")
    lst=[]
    for line in open(file):
        lst += str(line).split()
    print (lst)
    print (sorts(lst))

def sorts(lst):
    """
    function to sort the list alphabetically
    :param lst:
    :return:
    """
    for round in range(0,len(lst)-1):
        index = round
        while (lst[index]>lst[index+1] and index>=0):
            temp=lst[index]
            lst[index]=lst[index+1]
            lst[index+1]=temp
            index-=1
    return lst