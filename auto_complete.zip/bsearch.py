"""
Name: Varnit Tewari
Email: vxt6823@rit.edu
Function to operate binary search to find the word
It finds the first word starting with that prefix and then carries a linear search for all the words starting with that prefix after it,
 then it loops back and goes backwards and finds the words
"""


def lin_search2(lst, pre, mid_index, end):
    """
    function to search the word linearly from the starting word
    :param lst:
    :param pre:
    :param mid_index:
    :param end:
    :return:
    """
    lst4=[]
    e = mid_index + 1
    for i in range(e, len(lst) - 1):
        f = lst[i]
        if f[0:len(pre)] == pre:
            lst4 += [f]
    lst4 += lin_search3(lst,pre,mid_index,end)
    return lst4


def lin_search3(lst, pre, mid_index, end):
    """
    function to search backward from the first word
    :param lst:
    :param pre:
    :param mid_index:
    :param end:
    :return:
    """
    lst5=[]
    end = mid_index
    for j in range(end-1,-1,-1):
        h = lst[j]
        if h[0:len(pre)] == pre:
            lst5 += [h]
    return lst5



def bin_search(lst, pre, begin, end):
    """
    function to search for te first word with that prefix
    :param lst:
    :param pre:
    :param begin:
    :param end:
    :return:
    """
    lst3=[]
    mid_index = (begin + end) // 2
    mid_element = lst[mid_index]
    if mid_element[0:len(pre)] == pre:
        z=lin_search2(lst, pre, mid_index, end)
        lst3 += [mid_element]
        lst3 += z
        return lst3
    elif mid_element[0:len(pre)] < pre:
        return bin_search(lst, pre, mid_index + 1, end)
    else:
        return bin_search(lst, pre, begin, mid_index - 1)

def main():
    """
    Function to
    - promt the user for a file name
    - reads the words of the given file to a list
    - searches for the word
    :return:
    """
    file = input(" Enter file name:")
    lst=[]
    for line in open(file):
        lst += str(line).split()
    print (lst)
    print (sort(lst))
    pre = input(" Enter a prefix to search for :")
    if pre == "<QUIT>":
        print(" Exiting Auto-complete! Good bye.")
    begin=0
    end=len(lst)-1
    print (bin_search(lst,pre,begin,end))

def sort(lst):
    """
    sorts the function alphabetically
    :param lst:
    :return:
    """
    for round in range(0,len(lst)-1):
        index = round
        while (lst[index]>lst[index+1] and index>=0):
            temp=lst[index]
            lst[index]=lst[index+1]
            lst[index+1]=temp
            index-=1
    return lst