"""
Name: Varnit Tewari
Email:vxt6823@rit.edu
This code creates the list, adds elements to the list and removes elements from the list. This is just a helper code.
"""

from rit_lib import *
from dlNode import *

class dlList(struct):
    _slots = ( ((NoneType,Node), 'head'), ((NoneType,Node) ,'cursor') ,(int, 'size'))


def createList():
    """
    creates the list
    :return: empty list
    """
    return dlList(None,None,0)

def append(lst,value):
    """
    adds elements to the list
    :param lst:
    :param value:
    :return:
    """
    newNode= Node(value,None,None)
    if lst.head == None:
        lst.head = newNode
    else:
        curr = lst.head
        while curr.next != None:
            curr = curr.next
        newNode.previous=curr
        newNode.next=None
        curr.next=newNode
    lst.size+=1

def remove(lst,direction):
    """
    removes a specific element from the list
    :param lst:
    :param direction:
    :return:
    """
    if direction=="Clockwise":
        lst.cursor.previous.next=lst.cursor.next
        lst.cursor.next.previous=lst.cursor.previous
        lst.cursor=lst.cursor.next
    else:
        lst.cursor.previous.next = lst.cursor.next
        lst.cursor.next.previous = lst.cursor.previous
        lst.cursor =lst.cursor.previous
    lst.size-=1
