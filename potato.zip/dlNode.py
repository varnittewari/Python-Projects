"""
Name: Varnit Tewari
Email:vxt6823@rit.edu
This code is just to create a class that we use in the main code
"""

from rit_lib import *

class Node(struct):
    _slots= ( (object ,"data"),  ((NoneType,'Node'), "next"),((NoneType,'Node'), "previous"))