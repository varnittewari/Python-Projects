"""
Name: Varnit Tewari
Email:vxt6823@rit.edu
This code impllements the hot potato game played among pokemons. A potato is passed as the music starts and whoever is
caught with the potato at the end of music is out. Last person remaining in the game is the winner.
"""


from rit_lib import *
from dlList import *
from dlNode import *
import random

def main():
    """
    inputs the file name
    inputs the seed nummber
    calls various functions to run the code
    :return:
    """
    print ("Welcome to the Hot Potato Game!")
    file = input ("Enter a file of contestants:")
    intSeed=input ("Enter a seed number for random number generator:")
    random.seed(intSeed)
    string=""
    lst=createList()
    for line in open(file):
        append(lst,line.strip())
        string =string + str(line.strip()) +", "
    lst.cursor=lst.head
    string = string[0:len(string)-2]
    while lst.cursor.next!=None:
        lst.cursor=lst.cursor.next
    lst.cursor.next = lst.head
    lst.head.previous = lst.cursor
    starter=lst.cursor.next
    print (" Ready to play Hot Potato. Contestants are :", string)
    if lst.size==1:
        print ( lst.head.data, "is the winner")
    else:
        game(lst,starter)

def game(lst,starter):
    """
    this function implements the whole game by taking a random integer and the direction.
    :param lst: doubly linked list
    :param starter: pokemon to start with
    :return:
    """
    lst.cursor=starter
    str1="Clockwise"
    str2="Anticlockwise"
    while lst.size>1:
        passes=random.randint(-2*lst.size,2*lst.size)
        if passes==0:
            print (" The music starts(",passes,"):", lst.cursor.data,"is stuck holding the potato!")
            remove (lst,str1)
        elif passes>0:
            str3="The music starts("+ str(passes)+")"
            while passes>0 or passes==0:
                if passes==0:
                    str3 = str3 + str(lst.cursor.data)
                else:
                    str3=str3+str(lst.cursor.data)+"->"
                    lst.cursor=lst.cursor.next
                passes-=1
            print (str3,"is stuck holding the potato!")
            remove(lst,str1)
        else:
            str3 = "The music starts(" + str(passes) + ")"
            while passes < 0 or passes == 0:
                if passes == 0:
                    str3 = str3 + str(lst.cursor.data)
                else:
                    str3 = str3 + str(lst.cursor.data) + "->"
                    lst.cursor = lst.cursor.previous
                passes += 1
            print(str3, "is stuck holding the potato!")
            remove(lst, str2)
    print(lst.cursor.data,"is the winner!")

main()




