"""
Name: Varnit Tewari
Email: vxt6823@rit.edu
This function calculates the standard deviations that will behelpful in plotting the timelines and will
also be helpful in calculating the mean.
"""

import math
from indexTools import *

def average(nums):
    """
    This function calculates the average of the values given in he list.
    :param nums:A list of float values to average together.
    :return:A float representing the average value of the given numeric dataset
    """
    sum=0.0
    for i in range(len(nums)):
        sum+=nums[i]
    return sum/len(nums)


def deviation_squared(nums,avg):
    """
    It calculates the square of the deviation and puts thm in a list for a specific region
    :param nums: The nums is a list of numeric values
    :param avg:average of those values.
    :return An array of float values representing the square of the deviations of the data from
the data average.
    """
    lst=[]
    for i in range(len(nums)):
        deviation=avg-nums[i]
        lst.append(deviation**2)
    return lst


def measure_volatility(data):
    """
    It does all the calculation, sums the squares of the deviations for a specific region and makes tuple of
    (region, standard deviation) and adds the tuples to a list and then sorts from high to low values.
    :param data:The data is a dictionary from region to list of AnnualHPI values
    :return:A list of (region, standard_deviation) tuples sorted from high value to low
value.
    """
    lst1=[]
    for key in data:
        lst=[]
        for i in range(len(data[key])):
            lst.append(data[key][i].index)
        avg=average(lst)
        lst=deviation_squared(lst,avg)
        sum=0
        for i in range(len(lst)):
            sum+=lst[i]
        dev=sum/len(lst)
        stdev=math.sqrt(dev)
        lst1.append((key,stdev))
    lst1 = sorted(lst1, key=lambda x: (-x[1], x[1]))
    return lst1


def main():
    """
    main function to call other functions
    :return:
    """
    filename = input("Enter region based house price index filename:")
    region=input("Enter region of interest:")
    if 'state' in filename:
        data = read_state_house_price_data(filename)
        annual = annualize(data)
        lst=measure_volatility(annual)
        print_ranking(lst,"Annualized Price Standard Deviation, High to Low")
    elif 'ZIP' in filename:
        data = read_zip_house_price_data(filename)
        lst= measure_volatility(data)
        print_ranking(lst, "Annualized Price Standard Deviation, High to Low")
    else:
        raise Exception("Invalid entry")
    print("Note: Absence of data can increase the apparent variation.")
    for tup in lst:
        if tup[0]==region:
            print("Standard deviation for ",region,"is ",tup[1])


if __name__=='__main__':
    main()