"""
Name:Varnit Tewari
Email:vxt6823@rit.edu
This code  can compute the rankings of states or zip codes for a given year, or for a given year and a given quarter.
"""

from indexTools import *

def quarter_data(data,year,qtr):
    """
    It sorts the tuples of (region,HPI) from high to low. It has only QuarterHPI values
    :param data: dictionary
    :param year: year
    :param qtr: quarter we are interested in
    :return: A list of (region, HPI) tuples sorted from high value HPI to low value HPI.
    """
    lst=[]
    for key in data:
        #tup1=(key,)
        obj=data[key]
        for i in range(1,len(obj)):
            if obj[i].year==year and obj[i].qtr==qtr:
               lst.append((key,obj[i].index))
        lst = sorted(lst, key=lambda x: (-x[1], x[1]))
    return lst

def annual_data(data,year):
    """
    It sorts the tuples of (region,HPI) from high to low. It has only AnnualHPI values
    :param data: dictionary
    :param year: year
    :return:A list of (region, HPI) tuples sorted from high value HPI to low value HPI.
    """
    lst = []
    for key in data:
        obj = data[key]
        for i in range(0, len(obj)):
            if obj[i].year == year:
               lst.append((key,obj[i].index))
    lst=sorted(lst, key = lambda x: (-x[1],x[1]))
    return lst

def main():
    """
    main function to call every other function
    :return:
    """
    filename=input("Enter region based house price index filename:")
    year= int(input("Enter year of interest for house prices:"))
    if 'state' in filename:
        data=read_state_house_price_data(filename)
        annual=annualize(data)
        print_ranking(annual_data(annual,year),str(year)+" Annual Ranking")
    elif 'ZIP'in filename:
        data=read_zip_house_price_data(filename)
        print_ranking(annual_data(data,year),str(year)+" Annual Ranking")
    else:
        raise Exception("Invalid file path")


if __name__=='__main__':
    main()
