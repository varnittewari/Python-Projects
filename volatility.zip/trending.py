"""
Name: Varnit Tewari
Email: vxt6823 @rit.edu
This code computes the top and bottom trending regions
based on their growth between a given starting and a given ending year.
"""

from indexTools import *

def cagr(idxlist,periods):
    """
    This function does all the calculation
    :param idxlist:The idxlist is a 2-item list of [HPI0, HPI1]
    :param periods:The periods is the number (N) of periods (years) between the
two HPI values in the list.
    :return:A float representing the compound annual growth rate
    """
    return ((idxlist[1]/idxlist[0])**(1/periods)-1)*100


def calculate_trends(data,year0,year1):
    """
    This code makes a list of tuples(region,rate) from high to low
    :param data: dictionary
    :param year0: starting year
    :param year1: ending year
    :return: A list of (region, rate) tuples sorted in descending order by the compound
annual growth rate.
    """
    lst=[]
    for key in data:
        a=AnnualHPI(0,0.0)
        b=AnnualHPI(0,0.0)
        obj=data[key]
        for i in range(len(obj)):
            if obj[i].year==year0:
                a=obj[i]
            elif obj[i].year==year1:
                b=obj[i]
        if a.index!=0.0 and b.index!=0.0:
            idxlist=[a.index,b.index]
            rate=cagr(idxlist,year1-year0)
            tup=(key,rate)
            lst.append(tup)
        else:
            pass
    lst = sorted(lst, key=lambda x: (-x[1], x[1]))
    return lst


def main():
    """
    main function to call other functions
    :return:
    """
    filename=input("Enter house price index filename:")
    year1=int(input("Enter start year of interest:"))
    year2=int(input("Enter ending year of interest:"))
    if 'state' in filename:
        data = read_state_house_price_data(filename)
        annual = annualize(data)
        lst=calculate_trends(annual,year1,year2)
        print_ranking(lst,str(year1)+"-"+str(year2) + " Annual Growth Rate")
    elif 'ZIP' in filename:
        data=read_zip_house_price_data(filename)
        lst = calculate_trends(data, year1, year2)
        print_ranking(lst, year1+ "-"+ year2+ " Annual Growth Rate")
    else:
        raise Exception("Invalid file path")


if __name__=='__main__':
    main()