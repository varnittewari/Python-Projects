"""
Name: Varnit Tewari
Email: vxt6823@rit.edu
This code graphs changes in HPI values over time.
The program will produce 2 kinds of graph: a set of line graphs with one line for each region
requested, and a set of ‘box and whiskers’ diagrams for one or more regions.
"""


import numpy.ma as ma
import matplotlib.ticker as mticker
import matplotlib.pyplot as plt
import datetime as dt
import matplotlib.dates as mdates
import copy
from indexTools import *


def build_plottable_array(xyears,regiondata):
    """
    It makes a list that makes it easy to plot graphs.
    :param xyears: list of integer year values
    :param regiondata: a list of AnnualHPI objects.
    :return: An array suitable for plotting with the matplotlib module
"""
    lst=[]
    years = xyears.copy()
    for y in years:
        t=False
        for i in regiondata:
            if i.year==y:
                t=True
                lst.append(i.index)
                break
        if y in years and t==False:
            lst.append(0)
    for k in range(len(lst)):
        if lst[k]==0:
            lst[k]=ma.masked
    return lst


def filter_years(data,year0,year1):
    """
    It makes a dictionary only for a specific set of years
    :param data: a dictionary mapping from regions to lists of AnnualHPI
objects
    :param year0: starting year
    :param year1: ending year
    :return: dictionary mapping regions to lists of HPI values that are within the year0
to year1 inclusive range.
    """

    d={}
    for key in data:
        lst = []
        obj=data[key]
        for i in range(len(obj)):
            if obj[i].year==year0 or obj[i].year>year0:
                if obj[i].year<year1+1:
                    lst.append(obj[i])
        d[key]=lst
    return d


def plot_HPI(data,regionlist):
    """
    It plots the graph for the data
    :param data:a dictionary mapping a state or zip code to a list of AnnualHPI objects.
    :param regionlist:a list of key values whose type isstring.
    :return: None
    """
    lst1 = []
    lst2=[]
    for j in range(data[regionlist[0]][len(data[regionlist[0]])-1].year-data[regionlist[0]][0].year+1):
        lst2.append(data[regionlist[0]][0].year+j)
    for i in regionlist:
        lst=build_plottable_array(lst2,data[i])
        thing=plt.plot(lst2,lst,marker="*",label=i)
        lst1.append(thing)
    plt.legend(loc=2)
    plt.title("Home price indices:" +str(lst2[0])+" to "+ str(lst2[len(lst2)-1]))
    plt.show(lst1)


def plot_whiskers(data,regionlist):
    """
    It plots a box graph and whiskers .
    :param data: a dictionary mapping a state or zip code to a list of AnnualHPI objects.
    :param regionlist: a list of key values whose type isstring.
    :return: None
    """
    lst=[]
    for i in regionlist:
        val = []
        for obj in data[i]:
            val.append(obj.index)
        lst.append(val)
    thing=plt.boxplot(x=lst,labels=regionlist,whis='range',showmeans=True)
    plt.title("Home price index comparison. Median is a line. Mean is a square")
    plt.show(thing)


def main():
    """
    main function to run a standalone code
    :return:
    """
    file=input("Enter house price index filename:")
    year0=int(input("Enter the start year of the range to plot:"))
    year1=int(input("Enter the end year of the range to plot:"))
    reglst=[]
    while True:
        reg=input("Enter next region for plots (<ENTER> to stop):")
        if reg=="":
            break
        else:
            reglst.append(reg)
    if 'state' in file:
        for region in reglst:
            data = read_state_house_price_data(file)
            print_range(data, region)
            annual=annualize(data)
        d=filter_years(annual,year0,year1)
        plot_HPI(d,reglst)
        plot_whiskers(d,reglst)
    elif 'ZIP' in file:
        data=read_zip_house_price_data(file)
        d = filter_years(data, year0, year1)
        plot_HPI(d, reglst)
        plot_whiskers(d, reglst)
    else:
        raise Exception("Invalid entry")


if __name__=="__main__":
    main()
