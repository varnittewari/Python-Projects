"""
Name:Varnit Tewari
Email:vxt6823@rit.edu
This supporting module includes class definitions and utility functions/tools
used by the other programs; developing these utilities will be Task 0.

"""


from rit_lib import *

class QuarterHPI(struct):
    """
    class definition
• year: an integer representing the year of the index value.
• qtr: an integer representing the quarter of the year.
• index: a float representing the home price index.

    """
    _slots=((int, "year"),(int,"qtr"),(float,"index"))

class AnnualHPI(struct):
    """
    class definition
    year: an integer representing the year of the index value.
    index: a float representing the home price index.
    """
    _slots=((int,'year'),(float,'index'))

def read_state_house_price_data(filepath):
    """
    This function maps state abbreviations to lists of QuarterHPI objects. For
every state, there is exactly one list of QuarterHPI objects.
    :param filepath: filename
    :return: dictionary
    """
    d={}
    for line in open(filepath):
        line=line.split()
        if line[0]!="state":
            key = line[0]
            if len(line)<4:
                print(" Data unavailable")
                print ( line[0] , line[1], line[2] ,".. warning: data unavailable in original space")
            else:
                year=int(line[1])
                qtr=int(line[2])
                index=float(line[3])
                if key in d:
                    d[key].append(QuarterHPI(year,qtr,index))
                else:
                    d[key]=[(QuarterHPI(year,qtr,index))]
    return d

def read_zip_house_price_data(filepath):
    """
    This function maps zip codes to lists of AnnualHPI objects. For every zip
code, there is exactly one list of AnnualHPI objects.
    :param filepath: filename
    :return: dictionary
    """
    d={}
    count=0
    uncount=0
    for line in open(filepath):
        line=line.split()
        if line[0]!="state" and line[1]!="ZIP":
            key = line[0]
            if len(line)<4 or line[3]==".":
               uncount+=1
            else:
               line=line[:4]
               year=int(line[1])
               index=float(line[3])
               if key in d:
                   d[key].append(AnnualHPI(year, index))
               else:
                   d[key] = [(AnnualHPI(year, index))]
               count+=1
    print ("Count:", count, " ", "Uncounted:", uncount )
    return d


def index_range(data,region):
    """
    This function maps regions to lists of *HPI objects and a region name. The
objects may be either QuarterHPI or AnnualHPI objects.
    :param data: dictionary
    :param region: state or a zip code
    :return: tuple
    """
    obj=data[region]
    minidx=obj[0].index
    a=obj[0]
    maxidx=obj[len(obj)-1].index
    b=obj[len(obj)-1]
    for i in range(1,len(obj)-1):
        if obj[i].index<minidx:
            minidx=obj[i].index
            a=obj[i]
        if obj[i].index>maxidx:
            maxidx=obj[i].index
            b=obj[i]
    return (a,b)

def print_range(data,region):
    """
    This function maps regions to lists of *HPI objects and a region name.
    :param data: dictionary
    :param region: state or a zip code
    :return: None
"""
    tup=index_range(data,region)
    print (" Region:", region)
    print (" Low : year/quarter/index:",tup[0].year,"/",tup[0].qtr,"/",tup[0].index )
    print (" High : year/quarter/index:",tup[1].year,"/",tup[1].qtr,"/",tup[1].index )


def print_ranking(data,heading="Ranking"):
    """
    This function prints the first 10 and last 10 elements in the list
    :param data: dictionary
    :param heading: heading
    :return: None
    """
    print(heading)
    print(" The Top 10:")
    for i in range(10):
        print(i+1, ":", data[i])
    print (" The Bottom 10:")
    for i in range(len(data)-10,len(data)):
        print (i+1, ": ",data[i] )


def annualize(data):
    """
    It converts all the QuarterHPI objects to AnnualHPI
    :param data: dictionary
    :return: A dictionary mapping regions to lists of AnnualHPI objects
"""
    d={}
    for key in data:
        obj=data[key]
        sum=0
        count = 0
        y=obj[0].year
        for i in range(len(obj)):
            if obj[i].year==y:
                count+=1
                sum+=obj[i].index
            else:
                idx=sum/count
                if obj[i].index!=".":
                   if key in d:
                      d[key].append(AnnualHPI(int(y),float(idx)))
                   else:
                      d[key]=[AnnualHPI(int(y),float(idx))]
                count=1
                sum=obj[i].index
                y=obj[i].year
        if obj[i].index !=".":
            if key in d:
                d[key].append(AnnualHPI(int(y), float(obj[i].index)))
            else:
                d[key] = [AnnualHPI(int(y), float(obj[i].index))]
    return d


def main():
    """
    main function to call other functions
    :return:
    """
    file=input("Enter house price index file:")
    reglst = []
    while True:
        reg = input("Enter next region for plots (<ENTER> to stop):")
        if reg == "":
            break
        else:
            reglst.append(reg)
    if 'state' in file:
        for region in reglst:
            data = read_state_house_price_data(file)
            print_range(data, region)
            annual = annualize(data)
            for i in reglst:
                print ("Annualized index values for ", i)
                for obj in annual[i]:
                    print(obj)
    elif 'ZIP' in file:
        data=read_zip_house_price_data(file)
    else:
        raise Exception("Invalid input")

if __name__=='__main__':
    main()


