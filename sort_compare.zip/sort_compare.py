"""
Name: Varnit Tewari
Email:vxt6823@rit.edu
To compare all the types of sorts we have done in the semester and print their run time.
"""


import random
import time
from rit_lib import *
import sys


sys.setrecursionlimit(10000)


class Heap(struct):
    """
       A heap inside an array that may be bigger than the
       heapified section of said array
       SLOTS:
           array: the Python list object used to store the heap
           size: the number of array elements currently in the
                 heap. (size-1) is the index of the last element.
           compareFunc: A function to compare values in the heap.
                  For example, if compareFunc performs less-than,
                  then the heap will be a min-heap.
    """
    _slots = ((list, 'array'), (int, 'size'), (object, 'compareFunc'))


def createEmptyHeap(maxSize, compareFunc):
    """
       createEmptyHeap : NatNum * Function -> Heap
       Create an empty heap with capacity maxSize
       and comparison function compareFunc.
       Return initialized heap.
    """

    heap = Heap([None for _ in range(maxSize)], 0, compareFunc)
    return heap


def parent(i):
    """
       Return index of parent of node at index i.
    """
    return (i - 1) // 2


def lChild(i):
    """
       Return index of left child of node at index i.
    """
    return 2 * i + 1


def rChild(i):
    """
       Return index of right child of node at index i.
    """
    return 2 * i + 2


def siftUp(heap, startIndex):
    """
       siftUp : Heap * NatNum -> NoneType
       Move the value at startIndex up to its proper spot in
       the given heap. Assume that the value does not have
       to move down.
    """
    i = startIndex
    a = heap.array
    while i > 0 and not heap.compareFunc(a[parent(i)], a[i]):
        (a[parent(i)], a[i]) = (a[i], a[parent(i)])  # swap
        i = parent(i)



def _first_of_3(heap, index):
    """
    _first_of_3 : Heap * NatNum -> NatNum
    _first_of_3 is a private, utility function.
       Look at the values at:
       - index
       - the left child position of index, if in the heap
       - the right child position of index, if in the heap
       and return the index of the value that should come
       first, according to heap.compareFunc().
    """
    lt = lChild(index)
    rt = rChild(index)
    thisVal = heap.array[index]
    if rt < heap.size:  # If there are both left and right children
        lVal = heap.array[lt]
        rVal = heap.array[rt]
        if heap.compareFunc(lVal, thisVal) \
                or heap.compareFunc(rVal, thisVal):
            if heap.compareFunc(lVal, rVal):
                return lt  # The left child goes first
            else:
                return rt  # The right child goes first
        else:
            return index  # This one goes first
    elif lt < heap.size:  # If there is only a left child
        lVal = heap.array[lt]
        if heap.compareFunc(lVal, thisVal):
            return lt  # The left child goes first
        else:
            return index  # This one goes first
    else:  # There are no children
        return index


def siftDown(heap, startIndex):
    """
       siftDown : Heap * NatNum -> NoneType
       Move the value at startIndex down to its proper spot in
       the given heap. Assume that the value does not have
       to move up.
    """
    curIndex = startIndex
    a = heap.array
    swapIndex = _first_of_3(heap, curIndex)
    while (swapIndex != curIndex):
        (a[swapIndex], a[curIndex]) = (a[curIndex], a[swapIndex])  # swap
        curIndex = swapIndex
        swapIndex = _first_of_3(heap, curIndex)


def add(heap, newValue):
    """
       add : Heap * Comparable -> NoneType
       add inserts the element at the correct position in the heap.
    """
    if heap.size == len(heap.array):
        heap.array = heap.array + ([None] * len(heap.array))
    heap.array[heap.size] = newValue
    siftUp(heap, heap.size)
    heap.size = heap.size + 1


def removeMin(heap):
    """
       removeMin : Heap -> Comparable
       removeMin removes and returns the minimum element in the heap.
    """
    res = heap.array[0]
    heap.size = heap.size - 1
    heap.array[0] = heap.array[heap.size]
    heap.array[heap.size] = None
    siftDown(heap, 0)
    return res


def selectionsort(lst):
    """
    the code for selection sort
    :param lst:
    :return:
    """
    start=time.time()
    for i in range(len(lst)):
        min = i
        for k in range(i + 1, len(lst)):
            if lst[k] < lst[min]:
                min = k
        swap(lst, min, i)
    end=time.time()
    return end - start


def swap(A, x, y):
    """
    for swapping the numbers
    :param A:
    :param x:
    :param y:
    :return:
    """
    tmp = A[x]
    A[x] = A[y]
    A[y] = tmp


def insert_sort(lst):
    """
    the code for insertion sort
    :param lst:
    :return:
    """
    start=time.time()
    for index in range(1, len(lst)):
        currVal = lst[index]
        position = index
        while position > 0 and lst[position - 1] > currVal:
            lst[position] = lst[position - 1]
            position = position - 1
        lst[position] = currVal
    end=time.time()
    return (end-start)


def less(n1,n2):
    """
    determines lesser of the two
    :param n1:
    :param n2:
    :return:
    """
    return n1<=n2


def heap_sort(lst):
    """
    code for the heap sort
    :param lst:
    :return:
    """
    start = time.time()
    sortlst=[]
    heap = createEmptyHeap(len(lst), less)
    for i in range(len(lst)):
        add(heap, lst[i])
    while heap.size>0:
        minnum=removeMin(heap)
        sortlst.append(minnum)
    end=time.time()
    return end - start


def split(L):
    """
    for splitting the list into two halves
    :param L:
    :return:
    """
    half1=[]
    half2 = []
    onEvenPos = True
    for e in L:
        if onEvenPos:
            half1.append(e)
        else:
            half2.append(e)
        onEvenPos = not onEvenPos
    return(half1, half2)


def merge(sorted1, sorted2):
    """
    merging the two lists
    :param sorted1:
    :param sorted2:
    :return:
    """
    result = []
    index1 = 0
    index2 = 0
    while index1 < len(sorted1) and index2 < len(sorted2):
        if sorted1[index1] <= sorted2[index2]:
            result.append(sorted1[index1])
            index1 = index1 + 1
        else:
            result.append(sorted2[index2])
            index2 = index2 + 1

    if index1 < len( sorted1 ):
        result.extend( sorted1[index1:] )
    elif index2 < len( sorted2 ):
        result.extend( sorted2[index2:] )
    return result


def merge_sort(L):
    """
    the code for the merge sort
    :param L:
    :return:
    """
    if len(L)==1:
        return L
    else:
        (L1, L2) = split(L)
        sorted1 = merge_sort(L1)
        sorted2 = merge_sort(L2)
        sortedAll = merge(sorted1, sorted2)
    return sortedAll


def quickSort(L):
    """
    the code for the quick sort
    :param L:
    :return:
    """

    if L == []:
        return []
    else:
        pivot= L[0]
        ( less , same , more ) = partition( pivot , L )
        sortedLess= quickSort(less)
        sortedMore= quickSort(more)
        sortedAll=  sortedLess+ same + sortedMore
    return sortedAll


def partition ( pivot , L ):
    """
    divides the list into three halves
    :param pivot:
    :param L:
    :return:
    """
    ( less , same , more ) = ( [], [], [] )
    for e in L:
        if e < pivot:
            less.append( e )
        else:
            if e > pivot:
                more.append( e )
            else:
                same.append( e )
    return ( less , same , more )



def main():
    """
    main function to execute everything
    :return:
    """
    min=int(input("What is the min possible value of an item in the list:"))
    max=int(input("What is the max possible value of an item in the list:"))
    size=int(input("What is the size of the list:"))
    a=input("Do you want to display the list? (Y/N)")
    lst = []
    for i in range(size):
        lst.append(random.randint(min, max))
    if a=="Y":
        print("The random list is:", lst)
    lst1=lst.copy()
    lst2=lst.copy()
    lst3=lst.copy()
    lst4=lst.copy()
    print (" Insertion sort time: ", insert_sort(lst1))
    print (" Selection sort time: ", selectionsort(lst2))
    print(" Heap sort time: ", heap_sort(lst3))
    start=time.time()
    merge_sort(lst4)
    end=time.time()
    print(" Merge sort time: ", end-start)
    start1 = time.time()
    quickSort(lst)
    end1=time.time()
    print(" Quick sort time: ", end1-start1)


def test_insert():
    """
    test function for insert
    :return:
    """
    lst = []
    for i in range(10):
        lst.append(random.randint(1, 10))
    ulst=lst.copy()
    slst=insert_sort(ulst)
    lst.sort()
    if slst==lst:
        print("True")


def test_select():
    """
    test function for selection sort
    :return:
    """
    lst = []
    for i in range(10):
        lst.append(random.randint(1, 10))
    ulst=lst.copy()
    slst=selectionsort(ulst)
    lst.sort()
    if slst==lst:
        print("True")


def test_merge():
    """
    test function for merge sort
    :return:
    """
    lst = []
    for i in range(10):
        lst.append(random.randint(1, 10))
    ulst=lst.copy()
    slst=merge_sort(ulst)
    lst.sort()
    if slst==lst:
        print("True")


def test_quick():
    """
    test function for quick sort
    :return:
    """
    lst = []
    for i in range(10):
        lst.append(random.randint(1, 10))
    ulst=lst.copy()
    slst=quickSort(ulst)
    lst.sort()
    if slst==lst:
        print("True")


def test_heap():
    """
    test function for heap sort
    :return:
    """
    lst = []
    for i in range(10):
        lst.append(random.randint(1, 10))
    ulst=lst.copy()
    slst=heap_sort(ulst)
    lst.sort()
    if slst==lst:
        print("True")


main()